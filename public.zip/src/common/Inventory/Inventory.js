import React from "react";

const Inventory = () => {
  return (
    <div>
      <h1>This is Inventory</h1>
    </div>
  );
};

export default Inventory;
