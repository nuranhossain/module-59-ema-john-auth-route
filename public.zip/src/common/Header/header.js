import React from "react";
import logo from "../../images/Logo.svg";
import "./header.css";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <div>
      <div className="container">
        <nav className="menu-bar">
          <div className="logo">
            <img src={logo} alt="logo" />
          </div>
          <div className="bar">
            <ul className="mybar">
              <li>
                <Link to="/">Shop</Link>
              </li>
              <li>
                <Link to="/orders">Orders</Link>
              </li>
              <li>
                <Link to="/inventory">Inventory</Link>
              </li>
              <li>
                <Link to="/about">About</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default Header;
